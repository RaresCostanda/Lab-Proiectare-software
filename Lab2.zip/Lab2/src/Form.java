public class Form {
    private String color;
    //private String shape;
    public Form() {
        this.color="white";
    }
    public Form(String color){
        this.color=color;
        //shape= shape;
    }

    public float getArea(){
        return 0;
    }
   @Override
    public String toString(){
        color=color;
        System.out.println("This form has the color "+color);
        return "This form has the color "+color;
    }
}
