public interface Node {
    int getValue();
    void setValue(int value);
}
